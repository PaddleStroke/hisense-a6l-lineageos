// SPDX-License-Identifier: Apache-2.0
// Hisense A6L radio HAL, r5 review round8 F61 (28 Sep 2026): NITZ age. IRadioNetworkIndication.nitzTimeReceived takes
// receivedTimeMs = when the HAL sends the indication (elapsedRealtime) and ageMs = how long the sample was cached in
// the RIL/modem, both on the suspend-inclusive boot clock; Android's NitzSignal uses receivedTimeMs - ageMs as the
// sample's reference time. ModemCore stamps the QMI indication with bootTimeMs() (CLOCK_BOOTTIME, the clock behind
// android::elapsedRealtime) on the QMI dispatch thread; the HAL forwards it later from the worker queue.
// Host-tested in tests/review7_tests.cc.
#pragma once

#include <cstdint>
#include <ctime>
#include <optional>

namespace android::hardware::radio::a6l {

inline int64_t bootTimeMs() {
    timespec ts{};
    clock_gettime(CLOCK_BOOTTIME, &ts);
    return static_cast<int64_t>(ts.tv_sec) * 1000 + ts.tv_nsec / 1000000;
}

// Age to report for a sample stamped at receivedBootMs and sent at nowBootMs (same clock). No modem-provided age is
// known for QMI NAS Network Time (the modem sends it as it decodes the network message), so the RIL queue time is the
// age. An invalid stamp (missing, or later than now) is discarded (nullopt) rather than sent with age 0.
inline std::optional<int64_t> nitzAgeMs(int64_t receivedBootMs, int64_t nowBootMs) {
    if (receivedBootMs <= 0 || receivedBootMs > nowBootMs) return std::nullopt;
    return nowBootMs - receivedBootMs;
}

}  // namespace android::hardware::radio::a6l

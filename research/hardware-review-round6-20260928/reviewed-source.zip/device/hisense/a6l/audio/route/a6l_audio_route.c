// SPDX-License-Identifier: Apache-2.0
/*
 * a6l-audio-route (audio3, 24 Sep 2026): mixer routing for the Hisense A6L "Hisense A6L" ASoC card.
 *
 * The AOSP AIDL example audio HAL (com.android.hardware.audio, module "primary") only opens ALSA card 0 / device 0 and
 * never sets mixer controls. This daemon owns the mixer instead: it loads /vendor/etc/mixer_paths_a6l.xml with
 * libaudioroute (the same parser the CAF/legacy HALs use), then follows the ASoC jack kcontrols of the card:
 *   "Headphone Jack" on  -> output path "headphones", otherwise "speaker" (or "headphones" when the card has no
 *                           TERT_MI2S speaker route, i.e. a DT without the TFA9894, so the output is never left dangling)
 *   "Mic Jack" on        -> input path "headset-mic", otherwise "main-mic"
 * The top level of the XML keeps MultiMedia1 connected to LPI_MI2S_RX_0 / LPI_MI2S_TX_3 at all times, so the HAL's
 * pcmC0D0p/c opens never fail with "no backend DAIs" (EINVAL). Polls every 300 ms (no dependency on mixer event APIs).
 * rom-v2 (agent merge, 25 Sep 2026): in-call routing while vendor.a6l.voice.active=1 (set by the radio HAL during a
 * call; a6l-q6voiced then holds the VoiceMMode1 PCMs and the DSP voice routes).
 *
 * r5 review fix F7 (28 Sep 2026):
 *  - In a call the route follows ANDROID's choice, published by the audio HAL (tree patch audio/patches/0002, from the
 *    Telephony Rx / Telephony Tx audio patches the audio policy creates) in vendor.a6l.audio.call_out
 *    (speaker|earpiece|headset|headphone|bt-sco) and vendor.a6l.audio.call_in (main|headset|bt-sco):
 *      speaker   -> "voice-speaker" (TFA9894 voice profile; a6l-q6voiced moves the DSP voice RX port to TERT_MI2S_RX)
 *      earpiece  -> "voice-handset";  headset/headphone -> "voice-headphones" (only while the jack reports a plug)
 *      bt-sco    -> not supported yet (no HFP/SCO audio path): logged as unsupported, jack-based fallback
 *      unset     -> jack-based default (headset if plugged, else earpiece), the rom-v2 behaviour
 *  - apply() returns success; the cached state is only committed after a successful apply, so a failed route is
 *    retried on the next poll. libaudioroute ignores failed control writes, so the controls that define each path are
 *    read back. After 3 consecutive failures, or when the card index changed/disappeared (ADSP/card loss), the mixer
 *    and the route are released and the card is reopened.
 * usage: a6l-audio-route [-x mixer_paths.xml] [-n card_name] [-1]   (-1: apply once for the current state and exit)
 */
#define LOG_TAG "a6l-audio-route"
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <cutils/properties.h>
#include <log/log.h>
#include <tinyalsa/asoundlib.h>
#include <audio_route/audio_route.h>

#define DEFAULT_XML "/vendor/etc/mixer_paths_a6l.xml"
#define DEFAULT_CARD_NAME "Hisense A6L"
#define MAX_FAILS_BEFORE_REOPEN 3

static int find_card(const char *want)
{
	for (unsigned int c = 0; c < 8; c++) {
		struct mixer *m = mixer_open(c);
		if (!m)
			continue;
		const char *n = mixer_get_name(m);
		int match = n && !strcmp(n, want);
		mixer_close(m);
		if (match)
			return (int)c;
	}
	return -1;
}

/* returns 1/0 for a BOOL control, -1 if missing or unreadable */
static int get_bool(struct mixer *m, const char *name)
{
	struct mixer_ctl *ctl = mixer_get_ctl_by_name(m, name);
	if (!ctl)
		return -1;
	int v = mixer_ctl_get_value(ctl, 0);
	if (v < 0)
		return -1;
	return v > 0 ? 1 : 0;
}

/* ---------------------------------------------------------------- decision (pure, host-tested) */
struct route_state {
	int hp, mic, voice, has_spk;
	const char *call_out, *call_in;	/* Android's call devices (audio HAL properties), "" = unknown */
};

struct route_choice {
	const char *out, *in;
	int unsupported;	/* Android asked for a device without an audio path (BT SCO): fallback used */
};

static void decide(const struct route_state *s, struct route_choice *c)
{
	const char *co = s->call_out ? s->call_out : "", *ci = s->call_in ? s->call_in : "";

	c->unsupported = 0;
	c->in = (s->mic == 1) ? "headset-mic" : "main-mic";
	if (!s->voice) {
		c->out = (s->hp == 1 || !s->has_spk) ? "headphones" : "speaker";
		return;
	}
	c->out = (s->hp == 1) ? "voice-headphones" : "voice-handset";	/* jack-based default */
	if (!strcmp(co, "speaker")) {
		if (s->has_spk)
			c->out = "voice-speaker";
		else
			c->unsupported = 1;
	} else if (!strcmp(co, "earpiece")) {
		c->out = "voice-handset";
	} else if (!strcmp(co, "headset") || !strcmp(co, "headphone")) {
		/* stale property after an unplug: the jack wins */
		c->out = (s->hp == 1) ? "voice-headphones" : "voice-handset";
	} else if (!strcmp(co, "bt-sco")) {
		c->unsupported = 1;	/* placeholder: HFP/SCO audio is not integrated */
	}
	if (!strcmp(ci, "main")) {
		c->in = "main-mic";
	} else if (!strcmp(ci, "headset")) {
		c->in = (s->mic == 1) ? "headset-mic" : "main-mic";
	} else if (!strcmp(ci, "bt-sco")) {
		c->unsupported = 1;
	}
	/* speakerphone: always the main (bottom) microphone, whatever the jack says about a headset mic */
	if (!strcmp(c->out, "voice-speaker") && strcmp(ci, "headset"))
		c->in = "main-mic";
}

/* ---------------------------------------------------------------- apply + verify */
/* 1 when the control reads back as `want` (enum string or integer), 0 when it differs, -1 unreadable */
static int ctl_is(struct mixer *m, const char *name, const char *want)
{
	struct mixer_ctl *ctl = mixer_get_ctl_by_name(m, name);
	if (!ctl)
		return -1;
	int v = mixer_ctl_get_value(ctl, 0);
	if (v < 0)
		return -1;
	if (mixer_ctl_get_type(ctl) == MIXER_CTL_TYPE_ENUM) {
		const char *s = mixer_ctl_get_enum_string(ctl, (unsigned int)v);
		return s && !strcmp(s, want) ? 1 : 0;
	}
	return v == atoi(want) ? 1 : 0;
}

/* the control that proves each path took effect (libaudioroute does not report failed writes) */
static const struct { const char *path, *ctl, *value; } VERIFY[] = {
	{ "headphones", "HPHL", "Switch" },
	{ "speaker", "TERT_MI2S_RX Audio Mixer MultiMedia1", "1" },
	{ "voice-headphones", "HPHL", "Switch" },
	{ "voice-handset", "EAR_S", "Switch" },
	{ "voice-speaker", "TFA Profile", "voice" },
	{ "main-mic", "Digital DEC1 MUX", "ADC1" },
	{ "headset-mic", "Digital DEC1 MUX", "ADC2" },
};

static int verify_path(struct mixer *m, const char *path)
{
	for (size_t i = 0; i < sizeof(VERIFY) / sizeof(VERIFY[0]); i++) {
		if (strcmp(VERIFY[i].path, path))
			continue;
		int r = ctl_is(m, VERIFY[i].ctl, VERIFY[i].value);
		if (r != 1) {
			ALOGE("verify %s: '%s' %s", path, VERIFY[i].ctl, r < 0 ? "unreadable" : "not applied");
			return -EIO;
		}
	}
	return 0;
}

/* 0 on success, negative errno otherwise (nothing is cached by the caller then) */
static int apply(struct audio_route *ar, struct mixer *m, const char *out, const char *in)
{
	audio_route_reset(ar);
	if (audio_route_apply_path(ar, out) < 0) {
		ALOGE("apply_path(%s) failed", out);
		return -EINVAL;
	}
	if (audio_route_apply_path(ar, in) < 0) {
		ALOGE("apply_path(%s) failed", in);
		return -EINVAL;
	}
	if (audio_route_update_mixer(ar) < 0) {
		ALOGE("update_mixer failed");
		return -EIO;
	}
	int r = verify_path(m, out);
	if (!r)
		r = verify_path(m, in);
	if (r) {
		printf("A6L_AUDIO_ROUTE_FAIL out=%s in=%s\n", out, in);
		fflush(stdout);
		return r;
	}
	ALOGI("route: out=%s in=%s", out, in);
	printf("A6L_AUDIO_ROUTE out=%s in=%s\n", out, in);
	fflush(stdout);
	return 0;
}

/* ---------------------------------------------------------------- loop */
struct routed {
	int card, has_spk;
	struct audio_route *ar;
	struct mixer *m;
	/* committed (successfully applied) state; last_hp = -2 forces an apply */
	int last_hp, last_mic, last_voice;
	char last_out_dev[PROPERTY_VALUE_MAX], last_in_dev[PROPERTY_VALUE_MAX];
	int fails;
};

static void route_close(struct routed *r)
{
	if (r->m)
		mixer_close(r->m);
	if (r->ar)
		audio_route_free(r->ar);
	r->m = NULL;
	r->ar = NULL;
	r->card = -1;
	r->last_hp = -2;
	r->fails = 0;
}

static int route_open(struct routed *r, int card, const char *xml)
{
	r->ar = audio_route_init((unsigned int)card, xml);
	r->m = mixer_open((unsigned int)card);
	if (!r->ar || !r->m) {
		ALOGE("init failed (card %d, xml %s)", card, xml);
		route_close(r);
		return -1;
	}
	r->card = card;
	r->has_spk = mixer_get_ctl_by_name(r->m, "TERT_MI2S_RX Audio Mixer MultiMedia1") != NULL;
	r->last_hp = -2;
	r->fails = 0;
	ALOGI("card %d, speaker route %s", card, r->has_spk ? "present" : "absent (headphones fallback)");
	return 0;
}

/* one poll: 0 nothing to do / applied, <0 apply failed (state not committed), 1 card lost -> reopen needed */
static int route_step(struct routed *r, const char *cname)
{
	char vp[PROPERTY_VALUE_MAX], co[PROPERTY_VALUE_MAX], ci[PROPERTY_VALUE_MAX];
	struct route_state s;
	struct route_choice c;

	property_get("vendor.a6l.voice.active", vp, "0");
	property_get("vendor.a6l.audio.call_out", co, "");
	property_get("vendor.a6l.audio.call_in", ci, "");
	s.hp = get_bool(r->m, "Headphone Jack");
	s.mic = get_bool(r->m, "Mic Jack");
	s.voice = vp[0] == '1';
	s.has_spk = r->has_spk;
	s.call_out = s.voice ? co : "";
	s.call_in = s.voice ? ci : "";
	if (s.hp == r->last_hp && s.mic == r->last_mic && s.voice == r->last_voice &&
	    !strcmp(s.call_out, r->last_out_dev) && !strcmp(s.call_in, r->last_in_dev))
		return 0;
	decide(&s, &c);
	if (c.unsupported)
		ALOGW("call device out='%s' in='%s' has no audio path (unsupported): using out=%s in=%s", s.call_out,
		      s.call_in, c.out, c.in);
	int ret = apply(r->ar, r->m, c.out, c.in);
	if (ret == 0) {
		r->last_hp = s.hp;
		r->last_mic = s.mic;
		r->last_voice = s.voice;
		snprintf(r->last_out_dev, sizeof(r->last_out_dev), "%s", s.call_out);
		snprintf(r->last_in_dev, sizeof(r->last_in_dev), "%s", s.call_in);
		r->fails = 0;
		return 0;
	}
	r->fails++;
	if (r->fails >= MAX_FAILS_BEFORE_REOPEN || find_card(cname) != r->card) {
		ALOGE("route failed %d time(s), card %d %s: reopening", r->fails, r->card,
		      find_card(cname) == r->card ? "still present" : "lost");
		return 1;
	}
	return ret;
}

#ifndef A6L_AUDIO_ROUTE_NO_MAIN
int main(int argc, char **argv)
{
	const char *xml = DEFAULT_XML, *cname = DEFAULT_CARD_NAME;
	int once = 0, opt;
	struct routed r = { .card = -1, .last_hp = -2 };

	while ((opt = getopt(argc, argv, "x:n:1")) != -1) {
		switch (opt) {
		case 'x': xml = optarg; break;
		case 'n': cname = optarg; break;
		case '1': once = 1; break;
		default:
			fprintf(stderr, "usage: %s [-x mixer_paths.xml] [-n card_name] [-1]\n", argv[0]);
			return 2;
		}
	}
	for (;;) {
		/* the card appears once the ADSP and all ASoC modules are up; wait for it (forever for the service) */
		int card, waited = 0;
		while ((card = find_card(cname)) < 0) {
			if (waited++ % 60 == 0)
				ALOGI("waiting for card '%s'", cname);
			if (once && waited > 30) {
				fprintf(stderr, "A6L_AUDIO_ROUTE_FAIL no card '%s'\n", cname);
				return 3;
			}
			sleep(1);
		}
		if (route_open(&r, card, xml)) {
			if (once) {
				fprintf(stderr, "A6L_AUDIO_ROUTE_FAIL init card=%d xml=%s\n", card, xml);
				return 4;
			}
			sleep(1);
			continue;
		}
		for (;;) {
			int ret = route_step(&r, cname);
			if (once)
				return ret == 0 ? 0 : 5;
			if (ret == 1)
				break;
			usleep(300 * 1000);
		}
		route_close(&r);
	}
}
#endif

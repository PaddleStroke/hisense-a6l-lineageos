/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include <libminradio/response.h>

namespace android::hardware::radio::minimal {

namespace aidl = ::aidl::android::hardware::radio;

aidl::RadioResponseInfo noError(int32_t serial) {
    return {
            .type = aidl::RadioResponseType::SOLICITED,
            .serial = serial,
            .error = aidl::RadioError::NONE,
    };
}

aidl::RadioResponseInfo notSupported(int32_t serial) {
    return {
            .type = aidl::RadioResponseType::SOLICITED,
            .serial = serial,
            .error = aidl::RadioError::REQUEST_NOT_SUPPORTED,
    };
}

aidl::RadioResponseInfo errorResponse(int32_t serial, aidl::RadioError error) {
    return {
            .type = aidl::RadioResponseType::SOLICITED,
            .serial = serial,
            .error = error,
    };
}

}  // namespace android::hardware::radio::minimal

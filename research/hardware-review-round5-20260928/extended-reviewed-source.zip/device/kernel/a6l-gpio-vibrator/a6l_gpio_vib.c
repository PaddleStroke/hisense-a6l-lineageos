// SPDX-License-Identifier: GPL-2.0-only
/*
 * a6l_gpio_vib (agent misc2, 25 Sep 2026): Hisense A6L vibrator.
 *
 * Stock does NOT use the PM660 haptics block (qcom,haptic@c000 is in the stock DT but the stock kernel has no
 * qpnp-haptic driver at all: no symbol, no string). The stock vibrator is "timed-gpio" (drivers/staging/android
 * timed_gpio.c, DT node timed-gpio { vib-gpio = <&tlmm 79 0>; pinctrl vib_en_pin: gpio79 output-low }):
 * timed_gpio_probe -> gpiod_direction_output_raw(gpio79, 0); gpio_enable(ms) -> raw level 1 (active_low = 0),
 * hrtimer off after min(ms, 15000). I.e. TLMM GPIO79 is the enable of a DC motor driver: high = vibrate.
 *
 * This driver exposes it as an input force-feedback device (memless) with FF_CONSTANT, FF_PERIODIC and FF_RUMBLE,
 * which is what vendor.qti.hardware.vibrator (VibratorOL, InputFFDevice) looks for (FF_CONSTANT || FF_PERIODIC),
 * and what the a6l_vib test tool uses (FF_RUMBLE). The motor has no amplitude control: any non-zero level = on.
 * FF_GAIN is provided by ff-memless (gain 0 = off).
 *
 * DT: compatible = "hisense,a6l-gpio-vibrator"; enable-gpios = <&tlmm 79 GPIO_ACTIVE_HIGH>; optional pinctrl.
 * debugfs a6l_gpio_vib/pulse (root, write "<ms>", 1..2000): one bounded pulse for the attended test.
 */
#include <linux/debugfs.h>
#include <linux/delay.h>
#include <linux/gpio/consumer.h>
#include <linux/input.h>
#include <linux/jiffies.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/of.h>
#include <linux/platform_device.h>
#include <linux/pm.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/uaccess.h>
#include <linux/workqueue.h>

#define A6L_VIB_MAX_MS	15000	/* stock timed-gpio max_timeout */

struct a6l_vib {
	struct device *dev;
	struct input_dev *input;
	struct gpio_desc *gpio;
	struct work_struct work;
	struct delayed_work pulse_off;
	spinlock_t lock;
	unsigned long active_types;	/* bit per FF type index that currently asks for vibration */
	bool suspended;
	bool on;
	bool pulse;
	struct dentry *dbg;
	unsigned long on_count;
};

static void a6l_vib_apply(struct a6l_vib *v)
{
	unsigned long flags;
	bool want;

	spin_lock_irqsave(&v->lock, flags);
	want = (v->active_types || v->pulse) && !v->suspended;
	spin_unlock_irqrestore(&v->lock, flags);
	if (want == v->on)
		return;
	gpiod_set_value_cansleep(v->gpio, want);
	v->on = want;
	if (want)
		v->on_count++;
	dev_dbg(v->dev, "A6L_VIB %s\n", want ? "on" : "off");
}

static void a6l_vib_work(struct work_struct *work)
{
	a6l_vib_apply(container_of(work, struct a6l_vib, work));
}

static int a6l_vib_type_idx(u16 type)
{
	switch (type) {
	case FF_RUMBLE: return 0;
	case FF_PERIODIC: return 1;
	case FF_CONSTANT: return 2;
	default: return -1;
	}
}

/* ff-memless play callback: called in atomic context with the COMBINED effect of one type (union zeroed first). */
static int a6l_vib_play(struct input_dev *dev, void *data, struct ff_effect *effect)
{
	struct a6l_vib *v = input_get_drvdata(dev);
	int idx = a6l_vib_type_idx(effect->type);
	bool on = memchr_inv(&effect->u, 0, sizeof(effect->u)) != NULL;
	unsigned long flags;

	if (idx < 0)
		return 0;
	spin_lock_irqsave(&v->lock, flags);
	if (on)
		__set_bit(idx, &v->active_types);
	else
		__clear_bit(idx, &v->active_types);
	spin_unlock_irqrestore(&v->lock, flags);
	schedule_work(&v->work);
	return 0;
}

static void a6l_vib_close(struct input_dev *input)
{
	struct a6l_vib *v = input_get_drvdata(input);
	unsigned long flags;

	spin_lock_irqsave(&v->lock, flags);
	v->active_types = 0;
	spin_unlock_irqrestore(&v->lock, flags);
	cancel_work_sync(&v->work);
	a6l_vib_apply(v);
}

static void a6l_vib_pulse_off(struct work_struct *work)
{
	struct a6l_vib *v = container_of(to_delayed_work(work), struct a6l_vib, pulse_off);
	unsigned long flags;

	spin_lock_irqsave(&v->lock, flags);
	v->pulse = false;
	spin_unlock_irqrestore(&v->lock, flags);
	a6l_vib_apply(v);
	dev_info(v->dev, "A6L_VIB pulse end (gpio=%d)\n", gpiod_get_value_cansleep(v->gpio));
}

static ssize_t a6l_vib_pulse_write(struct file *f, const char __user *ubuf, size_t len, loff_t *ppos)
{
	struct a6l_vib *v = file_inode(f)->i_private;
	unsigned int ms;
	unsigned long flags;
	int ret;

	ret = kstrtouint_from_user(ubuf, len, 0, &ms);
	if (ret)
		return ret;
	if (ms < 1 || ms > 2000)
		return -EINVAL;
	cancel_delayed_work_sync(&v->pulse_off);
	spin_lock_irqsave(&v->lock, flags);
	v->pulse = true;
	spin_unlock_irqrestore(&v->lock, flags);
	a6l_vib_apply(v);
	dev_info(v->dev, "A6L_VIB pulse %u ms (gpio=%d)\n", ms, gpiod_get_value_cansleep(v->gpio));
	schedule_delayed_work(&v->pulse_off, msecs_to_jiffies(ms));
	return len;
}

static const struct file_operations a6l_vib_pulse_fops = {
	.owner = THIS_MODULE,
	.open = simple_open,
	.write = a6l_vib_pulse_write,
};

static int a6l_vib_probe(struct platform_device *pdev)
{
	struct a6l_vib *v;
	int ret;

	v = devm_kzalloc(&pdev->dev, sizeof(*v), GFP_KERNEL);
	if (!v)
		return -ENOMEM;
	v->dev = &pdev->dev;
	spin_lock_init(&v->lock);
	INIT_WORK(&v->work, a6l_vib_work);
	INIT_DELAYED_WORK(&v->pulse_off, a6l_vib_pulse_off);

	/* stock: direction output, raw low at probe */
	v->gpio = devm_gpiod_get(&pdev->dev, "enable", GPIOD_OUT_LOW);
	if (IS_ERR(v->gpio))
		return dev_err_probe(&pdev->dev, PTR_ERR(v->gpio), "A6L_VIB no enable-gpios\n");

	v->input = devm_input_allocate_device(&pdev->dev);
	if (!v->input)
		return -ENOMEM;
	v->input->name = "a6l_gpio_vibrator";
	v->input->id.bustype = BUS_HOST;
	v->input->id.vendor = 0x2a6c;	/* same pseudo-vendor as the other A6L input devices */
	v->input->id.product = 0x0f01;
	v->input->close = a6l_vib_close;
	input_set_drvdata(v->input, v);
	input_set_capability(v->input, EV_FF, FF_RUMBLE);
	input_set_capability(v->input, EV_FF, FF_CONSTANT);
	input_set_capability(v->input, EV_FF, FF_PERIODIC);
	input_set_capability(v->input, EV_FF, FF_SQUARE);
	input_set_capability(v->input, EV_FF, FF_SINE);

	ret = input_ff_create_memless(v->input, NULL, a6l_vib_play);
	if (ret)
		return dev_err_probe(&pdev->dev, ret, "A6L_VIB ff create\n");
	ret = input_register_device(v->input);
	if (ret)
		return dev_err_probe(&pdev->dev, ret, "A6L_VIB input register\n");

	platform_set_drvdata(pdev, v);
	v->dbg = debugfs_create_dir("a6l_gpio_vib", NULL);
	debugfs_create_file("pulse", 0200, v->dbg, v, &a6l_vib_pulse_fops);
	debugfs_create_ulong("on_count", 0400, v->dbg, &v->on_count);
	dev_info(&pdev->dev, "A6L_VIB ready: gpio=%d (stock timed-gpio TLMM 79, high = on), input %s\n",
		 desc_to_gpio(v->gpio), dev_name(&v->input->dev));
	return 0;
}

static void a6l_vib_remove(struct platform_device *pdev)
{
	struct a6l_vib *v = platform_get_drvdata(pdev);
	unsigned long flags;

	debugfs_remove_recursive(v->dbg);
	cancel_delayed_work_sync(&v->pulse_off);
	spin_lock_irqsave(&v->lock, flags);
	v->pulse = false;
	v->active_types = 0;
	spin_unlock_irqrestore(&v->lock, flags);
	cancel_work_sync(&v->work);
	a6l_vib_apply(v);
	gpiod_set_value_cansleep(v->gpio, 0);
}

static int a6l_vib_suspend(struct device *dev)
{
	struct a6l_vib *v = dev_get_drvdata(dev);
	unsigned long flags;

	spin_lock_irqsave(&v->lock, flags);
	v->suspended = true;
	spin_unlock_irqrestore(&v->lock, flags);
	cancel_work_sync(&v->work);
	a6l_vib_apply(v);
	return 0;
}

static int a6l_vib_resume(struct device *dev)
{
	struct a6l_vib *v = dev_get_drvdata(dev);
	unsigned long flags;

	spin_lock_irqsave(&v->lock, flags);
	v->suspended = false;
	spin_unlock_irqrestore(&v->lock, flags);
	a6l_vib_apply(v);
	return 0;
}

static DEFINE_SIMPLE_DEV_PM_OPS(a6l_vib_pm, a6l_vib_suspend, a6l_vib_resume);

static const struct of_device_id a6l_vib_of_match[] = {
	{ .compatible = "hisense,a6l-gpio-vibrator" },
	{ }
};
MODULE_DEVICE_TABLE(of, a6l_vib_of_match);

static struct platform_driver a6l_vib_driver = {
	.probe = a6l_vib_probe,
	.remove = a6l_vib_remove,
	.driver = {
		.name = "a6l-gpio-vibrator",
		.of_match_table = a6l_vib_of_match,
		.pm = pm_sleep_ptr(&a6l_vib_pm),
	},
};
module_platform_driver(a6l_vib_driver);

MODULE_DESCRIPTION("Hisense A6L GPIO79 vibrator (stock timed-gpio equivalent) as an input FF device");
MODULE_LICENSE("GPL");
